﻿namespace MasterDetailsCoreAPITest.Models.DTOs
{
    public class ImgUpload
    {
        public string ImgName { get; set; }
    }
}
